# Rand Strings Syntax

- [CodePen Example](http://codepen.io/sol0mka/pen/QEpKwP?editors=0010)
- [back](/api/readme.md)

`Rand` string was designed to express random numeric values. Can be unit based (percents, pixels, rems etc.).


Full API reference:

```javascript
  // ...
  property : 'rand(min, max)',
  // ...

```

- [CodePen Example](http://codepen.io/sol0mka/pen/QEpKwP?editors=0010)
- [back](/api/readme.md)