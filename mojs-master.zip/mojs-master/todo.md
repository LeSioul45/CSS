## TODO
---

- check imediately return onRepeatComplete issue
- check timeline + tween again
- check callbacks order - onProgress should fire first

- cover COVER labels at tweener
- reafctor
- remove clamp for setProgress on tween

- fix coverage
- release
  - docs
  - tuts

- easing
  - add spring handler
- add meta balls
- add layers
- add states
- add shaker
- add line trails
- radial springs

# FIXES
- cover polyfills
- foreign context coordinates in burst
- add onChainUpdate to all the bits
- transit
  - fix timeline tween options history transform
  - fallback to x/y if translate isnt supported (transit should set x/y on svg)
- burst
  - add deltas for swirl swirlFrequency and swirlSize
  - then implementation

# UNDER CONSIDERATION
- add text tricks
- add backgrounds
- add camera glare


