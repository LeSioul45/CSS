# Patrons

Meet some of the outstanding guys that support `mojs` on [Patreon](https://patreon.com/user?u=3219311&utm_medium=social&utm_source=twitter&utm_campaign=creatorshare):

- [Zak Frisch](https://github.com/zfrisch)
- [Erhan Karadeniz](https://twitter.com/erhankaradeniz)
- [Jorge Antunes](https://github.com/stoikerty)
- [Daniel C. Henning](https://github.com/danielsdesk)
- [Chris Dolphin](https://github.com/likethemammal/)
- [Volodymyr Kushnir](https://twitter.com/VovaKushnir)
- [Wojtek Jodel]()
- [Roman Kuba](https://github.com/codebryo)
